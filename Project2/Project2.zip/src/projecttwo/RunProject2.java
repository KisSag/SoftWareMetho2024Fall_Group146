package projecttwo;

/**
 * {@code @author:} Tianxiang Huang
 */
public class RunProject2 {
    public static void main(String [] args) {
        new ClinicManager().run();
    }
}