package clinic;

/**
 * Last Modified: 9/29/2024
 * {@code @author:} Tianxiang Huang
 * Test: Done
 * 
 */
public class RunProject1 {
    public static void main(String [] args) { 
        new Scheduler().run(); 
    } 
}
